package com.example.serviceontime;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class myadapterGrid extends RecyclerView.Adapter<myviewholder1>{

    ArrayList<ModelGrid> data1;

    public myadapterGrid(ArrayList<ModelGrid> data1) {
        this.data1 = data1;
    }

    @NonNull
    @Override
    public myviewholder1 onCreateViewHolder(@NonNull ViewGroup parent1, int viewType) {
        LayoutInflater inflater1;
        inflater1 = LayoutInflater.from(parent1.getContext());
        View view = inflater1.inflate(R.layout.gridrow,parent1,false);
        return new myviewholder1(view);
    }

    @Override
    public void onBindViewHolder(@NonNull myviewholder1 holder1, int position) {
        holder1.grid_t1.setText(data1.get(position).getGrid_desc());
        holder1.grid_img.setImageResource(data1.get(position).getGrid_imgname());

    }

    @Override
    public int getItemCount() {
        return data1.size();
    }
}
