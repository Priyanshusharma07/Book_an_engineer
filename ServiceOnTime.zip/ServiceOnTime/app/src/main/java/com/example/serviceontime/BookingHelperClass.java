package com.example.serviceontime;

import java.util.jar.Attributes;

public class BookingHelperClass {
    String Name, Email, PhoneNo, PinCode, State, City, HouseNo, Area, Service, IssueDesc, Date, Time;

    public BookingHelperClass() {
        this.Name = Name;
    }



    public BookingHelperClass(String Name, String Email, String PhoneNo, String PinCode, String State, String City, String HouseNo, String Area, String Service, String IssueDesc, String Date, String Time) {
        this.Name = Name;
        this.Email = Email;
        this.PhoneNo = PhoneNo;
        this.PinCode = PinCode;
        this.State = State;
        this.City = City;
        this.HouseNo = HouseNo;
        this.Area = Area;
        this.Service = Service;
        this.IssueDesc = IssueDesc;
        this.Date = Date;
        this.Time = Time;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public String getPhoneNo() {
        return PhoneNo;
    }

    public void setPhoneNo(String phoneNo) {
        PhoneNo = phoneNo;
    }

    public String getPinCode() {
        return PinCode;
    }

    public void setPinCode(String pinCode) {
        PinCode = pinCode;
    }

    public String getState() {
        return State;
    }

    public void setState(String state) {
        State = state;
    }

    public String getCity() {
        return City;
    }

    public void setCity(String city) {
        City = city;
    }

    public String getHouseNo() {
        return HouseNo;
    }

    public void setHouseNo(String houseNo) {
        HouseNo = houseNo;
    }

    public String getArea() {
        return Area;
    }

    public void setArea(String area) {
        Area = area;
    }

    public String getService() {
        return Service;
    }

    public void setService(String service) {
        Service = service;
    }

    public String getIssueDesc() {
        return IssueDesc;
    }

    public void setIssueDesc(String issueDesc) {
        IssueDesc = issueDesc;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }

    public String getTime() {
        return Time;
    }

    public void setTime(String time) {
        Time = time;
    }
}
