package com.example.serviceontime;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class proAdapter extends RecyclerView.Adapter<proHolder> {

    ArrayList<proModel> Info;

    public proAdapter(ArrayList<proModel> info) {
        Info = info;
    }

    @NonNull
    @Override
    public proHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate(R.layout.professionalrow,parent,false);
        return new proHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull proHolder holder, int position) {
        holder.textView1.setText(Info.get(position).getEmpName());
        holder.textView2.setText(Info.get(position).getEmpDesc());
        holder.imageView.setImageResource(Info.get(position).getEmpImg());
        holder.imageView2.setImageResource(Info.get(position).getEmpRating());
    }

    @Override
    public int getItemCount() {
        return Info.size();
    }

}
