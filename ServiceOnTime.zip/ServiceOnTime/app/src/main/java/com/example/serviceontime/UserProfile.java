package com.example.serviceontime;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.se.omapi.Session;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Objects;

public class UserProfile extends AppCompatActivity {

    TextInputLayout FullName, Email, PhoneNo, Password;
    TextView fullNameLabel, usernameLabel;
    Button updateButton, logoutButton;
    FloatingActionButton bookButton;

    //    String _USERNAME, _NAME, _EMAIL, _PHONENO, _PASSWORD;
    DatabaseReference reference;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_profile);
        Objects.requireNonNull(getSupportActionBar()).hide();

        BottomNavigationView bottomNavigationView;
        bottomNavigationView = findViewById(R.id.bottomNavigation);

        bottomNavigationView.setSelectedItemId(R.id.menu_profile);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()){
                    case R.id.menu_home:
                        startActivity(new Intent(getApplicationContext(),
                                HomePage.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.menu_profile:
                        return true;
                    case R.id.menu_professional:
                        startActivity(new Intent(getApplicationContext(),
                                ProfessionalsView.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.menu_history:
                        startActivity(new Intent(getApplicationContext(),
                                BookingHistory.class));
                        overridePendingTransition(0,0);
                        return true;

                }
                return false;
            }
        });

        bookButton = findViewById(R.id.bookButtion);
        bookButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(UserProfile.this,BookingForm.class);
                startActivity(intent);
            }
        });


        reference = FirebaseDatabase.getInstance("https://serviceontimeapp-d7c17-default-rtdb.firebaseio.com/").getReference("Users");

        //Hooks
        FullName = findViewById(R.id.full_name_profile);
        Email = findViewById(R.id.email_profile);
        PhoneNo = findViewById(R.id.phoneNo_profile);
        Password = findViewById(R.id.password_profile);
        fullNameLabel = findViewById(R.id.full_name_top);
        usernameLabel = findViewById(R.id.username_top);
        updateButton = findViewById(R.id.update_btn);
        logoutButton = findViewById(R.id.logout_btn);

//        showAllUserData();

        SessionManager sessionManager = new SessionManager(this);
        HashMap<String, String> userDetails = sessionManager.getUserDetailFromSession();

        String fullName = userDetails.get(SessionManager.KEY_FULLNAME);
        String username = userDetails.get(SessionManager.KEY_USERNAME);
        String email = userDetails.get(SessionManager.KEY_EMAIL);
        String phoneNo = userDetails.get(SessionManager.KEY_PHONENO);
        String password = userDetails.get(SessionManager.KEY_PASSWORD);

        fullNameLabel.setText(fullName);
        usernameLabel.setText(username);
        FullName.getEditText().setText(fullName);
        Email.getEditText().setText(email);
        PhoneNo.getEditText().setText(phoneNo);
        Password.getEditText().setText(password);



        updateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                update();

            }
        });

        logoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SessionManager sessionManager = new SessionManager(UserProfile.this);
                sessionManager.logoutUserFromSession();

                Intent intent = new Intent(UserProfile.this, Login.class);
                Toast.makeText(UserProfile.this, "Logout Successfully!", Toast.LENGTH_SHORT).show();
                startActivity(intent);
            }
        });

    }

//    private void showAllUserData() {
//        Intent intent = getIntent();
//        _USERNAME = intent.getStringExtra("username");
//        _NAME = intent.getStringExtra("name");
//        _EMAIL = intent.getStringExtra("email");
//        _PHONENO = intent.getStringExtra("phoneNo");
//        _PASSWORD = intent.getStringExtra("password");
//
//        Objects.requireNonNull(FullName.getEditText()).setText(_NAME);
//        Objects.requireNonNull(Email.getEditText()).setText(_EMAIL);
//        Objects.requireNonNull(PhoneNo.getEditText()).setText(_PHONENO);
//        Objects.requireNonNull(Password.getEditText()).setText(_PASSWORD);
//
//
//    }

    public void update() {

        if (isNameChanged() || isPasswordChanged()) {
            Toast.makeText(this, "Data has been Updated" +
                    " Please Login Again", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(UserProfile.this, Login.class);
            startActivity(intent);
        } else {
            Toast.makeText(this, "Data is same & can't be Updated!", Toast.LENGTH_SHORT).show();
        }

    }

    private boolean isNameChanged() {

        SessionManager sessionManager = new SessionManager(this);
        HashMap<String, String> userDetails = sessionManager.getUserDetailFromSession();

        String fullName = userDetails.get(SessionManager.KEY_FULLNAME);
        String username = userDetails.get(SessionManager.KEY_USERNAME);

        if (!fullName.equals((FullName.getEditText()).getText().toString())) {
            reference.child(username).child("name").setValue(FullName.getEditText().getText().toString());
            FullName.getEditText().setText(fullName);
            fullNameLabel.setText(fullName);
            return true;
        } else {
            return false;
        }
    }

    private boolean isPasswordChanged() {
        SessionManager sessionManager = new SessionManager(this);
        HashMap<String, String> userDetails = sessionManager.getUserDetailFromSession();

        String username = userDetails.get(SessionManager.KEY_USERNAME);
        String password = userDetails.get(SessionManager.KEY_PASSWORD);


        if (!password.equals(Objects.requireNonNull(Password.getEditText()).getText().toString())) {
            reference.child(username).child("password").setValue(Objects.requireNonNull(Password.getEditText()).getText().toString());
//            _PASSWORD = FullName.getEditText().getText().toString();
            Password.getEditText().setText(password);
            return true;
        } else {
            return false;
        }
    }

}