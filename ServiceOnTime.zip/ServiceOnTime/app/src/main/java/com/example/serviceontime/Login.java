package com.example.serviceontime;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ActivityOptions;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Pair;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Objects;

public class Login extends AppCompatActivity {

    Button login_btn, callSignUp, forgot_pass;
    ImageView image;
    TextView logoText, sloganText;
    TextInputLayout username, password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        Objects.requireNonNull(getSupportActionBar()).hide();
        setContentView(R.layout.activity_login);
//        Hooks
        image= (ImageView)findViewById(R.id.imageView2);
        logoText= (TextView) findViewById(R.id.textView);
        sloganText= (TextView) findViewById(R.id.textView3);
        username= findViewById(R.id.username);
        password= findViewById(R.id.password);
        callSignUp = (Button) findViewById(R.id.signUp_screen);
        login_btn = findViewById(R.id.login_btn);
        forgot_pass = findViewById(R.id.fgt_pass);
//        login_btn = findViewById(R.id.signUpButton);

        SessionManager sessionManager = new SessionManager(this);
        HashMap<String, String> userDetails = sessionManager.getUserDetailFromSession();

        String username1 = userDetails.get(SessionManager.KEY_USERNAME);
        String password1 = userDetails.get(SessionManager.KEY_PASSWORD);

        username.getEditText().setText(username1);
        password.getEditText().setText(password1);
//

        callSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                Intent intent = new Intent(Login.this, SignUp.class);
                startActivity(intent);
//                Pair[] pairs;
//                pairs = new Pair[7];
//                pairs[0] = new Pair<View, String>(image, "logo_image");
//                pairs[1] = new Pair<View, String>(logoText, "logo_text");
//                pairs[2] = new Pair<View, String>(sloganText, "logo_dec");
//                pairs[3] = new Pair<View, String>(username, "username_tran");
//                pairs[4] = new Pair<View, String>(password, "password_tran");
//                pairs[5] = new Pair<View, String>(login_btn, "button1_tran");
//                pairs[6] = new Pair<View, String>(callSignUp, "button2_tran");
//
//                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
//                    ActivityOptions options = ActivityOptions.makeSceneTransitionAnimation(Login.this, pairs);
//                    startActivity(intent, options.toBundle());
//                }
            }
        });

        login_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                validateUsername();
                validatePassword();
                loginUser();
            }
        });

        forgot_pass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                Intent intent = new Intent(Login.this, HomePage.class);
//                startActivity(intent);
            }
        });

    }

    private boolean validateUsername(){
        String val = Objects.requireNonNull(username.getEditText()).getText().toString();

        if(val.isEmpty()){
            username.setError("Field Can't be Empty!");
            return false;
        }
        else{
            username.setError(null);
            username.setErrorEnabled(false);
            return true;
        }
    }

    private boolean validatePassword(){
        String val = Objects.requireNonNull(password.getEditText()).getText().toString();

        if (val.isEmpty()) {
            password.setError("Field cannot be empty");
            return false;
        }else {
            password.setError(null);
            password.setErrorEnabled(false);
            return true;
        }
    }

    private void loginUser(){
        if(!validateUsername() | !validatePassword()){
            return;
        }
        else{
            isUser();
        }
    }

    private void isUser() {
        String userEnteredUsername = Objects.requireNonNull(username.getEditText()).getText().toString();
        String userEnteredPassword = Objects.requireNonNull(password.getEditText()).getText().toString();

        DatabaseReference reference = FirebaseDatabase.getInstance("https://serviceontimeapp-d7c17-default-rtdb.firebaseio.com/").getReference("Users");

        Query checkUsers = reference.orderByChild("username").equalTo(userEnteredUsername);
        checkUsers.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists()){

                    username.setError(null);
                    username.setErrorEnabled(false);

                    String passwordFromDB = dataSnapshot.child(userEnteredUsername).child("password").getValue(String.class);
                    assert passwordFromDB != null;
                    if(passwordFromDB.equals(userEnteredPassword)){

                        username.setError(null);
                        username.setErrorEnabled(false);

                        String nameFromDB = dataSnapshot.child(userEnteredUsername).child("name").getValue(String.class);
                        String usernameFromDB = dataSnapshot.child(userEnteredUsername).child("username").getValue(String.class);
                        String phoneNoFromDB = dataSnapshot.child(userEnteredUsername).child("phoneNo").getValue(String.class);
                        String emailFromDB = dataSnapshot.child(userEnteredUsername).child("email").getValue(String.class);

                        SessionManager sessionManager = new SessionManager(Login.this);
                        sessionManager.createLoginSession(nameFromDB,usernameFromDB,emailFromDB,phoneNoFromDB,passwordFromDB);

                        Intent intent = new Intent(getApplicationContext(), HomePage.class);

                        intent.putExtra("name", nameFromDB);
                        intent.putExtra("username", usernameFromDB);
                        intent.putExtra("email", emailFromDB);
                        intent.putExtra("phoneNo", phoneNoFromDB);
                        intent.putExtra("password", passwordFromDB);

                        startActivity(intent);
                    }
                    else{
                        password.setError("Wrong Password!");
                        password.requestFocus();
                    }
                }
                else{
                    username.setError("No such User Exist!");
                    username.requestFocus();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) { }
        });
    }


}