package com.example.serviceontime;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;

import org.w3c.dom.Text;

import java.util.concurrent.TimeoutException;

public class BookingAdapter extends FirebaseRecyclerAdapter<BookingModel,BookingAdapter.myviewholder> {

    public BookingAdapter(@NonNull FirebaseRecyclerOptions<BookingModel> options) {
        super(options);
    }

    @Override
    protected void onBindViewHolder(@NonNull myviewholder holder, int position, @NonNull BookingModel model) {
        holder.Date.setText(model.getDate());
        holder.Name.setText(model.getName());
        holder.Contact.setText(model.getPhoneNo());
        holder.TimeSlot.setText(model.getTime());
        holder.Service.setText(model.getService());
        holder.IssueDescription.setText(model.getIssueDesc());
    }

    @NonNull
    @Override
    public myviewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.bookingsinglerow, parent,false);
        return new myviewholder(view);
    }

    class myviewholder extends RecyclerView.ViewHolder{
        TextView Date, Name, Contact, TimeSlot, Service, IssueDescription, Status;
        public myviewholder(@NonNull View itemView) {
            super(itemView);
            Date = (TextView)itemView.findViewById(R.id.Date);
            Name = (TextView)itemView.findViewById(R.id.BookBy);
            Contact = (TextView)itemView.findViewById(R.id.Contact);
            TimeSlot = (TextView)itemView.findViewById(R.id.TimeSlot);
            Service = (TextView)itemView.findViewById(R.id.ServiceType);
            IssueDescription = (TextView)itemView.findViewById(R.id.IssueDesc);
            Status = (TextView)itemView.findViewById(R.id.Status);
        }
    }
}
