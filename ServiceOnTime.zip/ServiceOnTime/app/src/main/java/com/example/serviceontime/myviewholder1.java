package com.example.serviceontime;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class myviewholder1 extends RecyclerView.ViewHolder{

    ImageView grid_img;
    TextView grid_t1;

    public myviewholder1(@NonNull View itemView) {
        super(itemView);
        grid_img = (ImageView)itemView.findViewById(R.id.grid_img1);
        grid_t1 = (TextView)itemView.findViewById(R.id.grid_t1);
    }
}
