package com.example.serviceontime;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;

import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Objects;

public class BookingHistory extends AppCompatActivity {

    BookingAdapter adapter;
    FloatingActionButton bookButton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_booking_history);
        Objects.requireNonNull(getSupportActionBar()).hide();


        RecyclerView recyclerView;
        recyclerView = findViewById(R.id.bookHistoryRecycler);

        LinearLayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(mLayoutManager);

        FirebaseRecyclerOptions<BookingModel> options =
                new FirebaseRecyclerOptions.Builder<BookingModel>()
                        .setQuery(FirebaseDatabase.getInstance().getReference().child("Booking_details"), BookingModel.class)
                        .build();

        adapter = new BookingAdapter(options);
        recyclerView.setAdapter(adapter);

        bookButton = findViewById(R.id.bookButtion);
        bookButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(BookingHistory.this,BookingForm.class);
                startActivity(intent);
            }
        });

        BottomNavigationView bottomNavigationView;
        bottomNavigationView = findViewById(R.id.bottomNavigation);

        bottomNavigationView.setSelectedItemId(R.id.menu_history);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()){
                    case R.id.menu_profile:
                        startActivity(new Intent(getApplicationContext(),
                                UserProfile.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.menu_history:
                        return true;
                    case R.id.menu_professional:
                        startActivity(new Intent(getApplicationContext(),
                                ProfessionalsView.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.menu_home:
                        startActivity(new Intent(getApplicationContext(),
                                HomePage.class));
                        overridePendingTransition(0,0);
                        return true;

                }
                return false;
            }
        });



    }

    @Override
    protected void onStart() {
        super.onStart();
        adapter.startListening();
    }

    @Override
    protected void onStop() {
        super.onStop();
        adapter.stopListening();
    }
}