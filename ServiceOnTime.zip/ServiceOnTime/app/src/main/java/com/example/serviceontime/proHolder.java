package com.example.serviceontime;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class proHolder extends RecyclerView.ViewHolder {

    ImageView imageView, imageView2;
    TextView textView1, textView2;

    public proHolder(@NonNull View itemView) {
        super(itemView);
        imageView = (ImageView)itemView.findViewById(R.id.img1);
        imageView2 = (ImageView)itemView.findViewById(R.id.img2);
        textView1 = (TextView)itemView.findViewById(R.id.t1);
        textView2 = (TextView)itemView.findViewById(R.id.t2);
    }
}
