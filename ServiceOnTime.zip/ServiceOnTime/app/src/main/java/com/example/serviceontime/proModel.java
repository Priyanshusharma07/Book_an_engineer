package com.example.serviceontime;

public class proModel {
    private String EmpName;
    private String EmpDesc;
    private int EmpImg;
    private int EmpRating;

    public int getEmpRating() {
        return EmpRating;
    }

    public void setEmpRating(int empRating) {
        EmpRating = empRating;
    }

    public String getEmpName() {
        return EmpName;
    }

    public void setEmpName(String empName) {
        EmpName = empName;
    }

    public String getEmpDesc() {
        return EmpDesc;
    }

    public void setEmpDesc(String empDesc) {
        EmpDesc = empDesc;
    }

    public int getEmpImg() {
        return EmpImg;
    }

    public void setEmpImg(int empImg) {
        EmpImg = empImg;
    }
}
