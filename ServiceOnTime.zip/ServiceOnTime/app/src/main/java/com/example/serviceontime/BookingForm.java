package com.example.serviceontime;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Objects;

public class BookingForm extends AppCompatActivity {

    TextInputLayout bookName, bookPhoneNo, bookEmail, bookPinCode, bookState, bookCity, bookHouseNo, bookArea, bookService, bookTime, bookIssueDesc, bookDate;
    EditText inputDate1;
    Button bookSubmit;
    int maxId = 0;

    String[] items = {"Punjab","Delhi","Hyderabad","Pune","Chennai","Bangalore","Mumbai"};
    String[] items1 = {"Electrical", "Plumbing", "Carpenter"};
    String[] items2 = {"8am - 9am", "9am - 10am", "10am - 11am", "11am - 12pm", "12pm - 1pm", "1pm - 2pm", "2pm - 3pm", "3pm - 4pm", "4m - 5pm", "5pm - 6pm", "6pm - 7pm", "7pm - 8pm"};

    AutoCompleteTextView autoCompleteTxt;
    ArrayAdapter<String> adapterItems;
    AutoCompleteTextView autoCompleteTxt1;
    ArrayAdapter<String> adapterItems1;
    AutoCompleteTextView autoCompleteTxt2;
    ArrayAdapter<String> adapterItems2;

    int year, month, day;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Objects.requireNonNull(getSupportActionBar()).hide();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_booking_form);

//        Spinner stateSpinner = findViewById(R.id.State);
//
//        ArrayAdapter<String> myAdapter = new ArrayAdapter<String>(BookingForm.this,
//                android.R.layout.simple_list_item_1, getResources().getStringArray(R.array.stateArray));
//
//        myAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
//        stateSpinner.setAdapter(myAdapter);
        FirebaseDatabase rootNode = FirebaseDatabase.getInstance("https://serviceontimeapp-d7c17-default-rtdb.firebaseio.com/");
        DatabaseReference reference = rootNode.getReference("Booking_details");

        bookName = findViewById(R.id.bookFullName);
        bookPhoneNo = findViewById(R.id.bookEmail);
        bookEmail = findViewById(R.id.bookPhoneNo);
        bookPinCode = findViewById(R.id.bookPinCode);
        bookState = findViewById(R.id.bookState);
        bookCity = findViewById(R.id.bookCity);
        bookHouseNo = findViewById(R.id.bookHouseNo);
        bookArea = findViewById(R.id.bookArea);
        bookService = findViewById(R.id.bookService);
        bookIssueDesc = findViewById(R.id.bookIssueDesc);
        bookDate = findViewById(R.id.bookDate1);
        inputDate1 = findViewById(R.id.inputDate);
        bookTime = findViewById(R.id.bookTime);
        bookSubmit = findViewById(R.id.bookSubmit);

        final Calendar calendar = Calendar.getInstance();
        inputDate1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                year = calendar.get(Calendar.YEAR);
                month = calendar.get(Calendar.MONTH);
                day = calendar.get(Calendar.DAY_OF_MONTH);
                DatePickerDialog datePickerDialog = new DatePickerDialog(BookingForm.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
                        inputDate1.setText(SimpleDateFormat.getDateInstance().format(calendar.getTime()));
                    }
                },year, month, day);
                datePickerDialog.show();
            }
        });


        autoCompleteTxt = findViewById(R.id.State);
        adapterItems = new ArrayAdapter<String>(this, R.layout.list_item,items);
        autoCompleteTxt.setAdapter(adapterItems);
        autoCompleteTxt.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String item = parent.getItemAtPosition(position).toString();
                Toast.makeText(getApplicationContext(),"Selected "+item, Toast.LENGTH_SHORT).show();
            }
        });

        autoCompleteTxt1 = findViewById(R.id.Service);
        adapterItems1 = new ArrayAdapter<String>(this, R.layout.list_item,items1);
        autoCompleteTxt1.setAdapter(adapterItems1);
        autoCompleteTxt1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String items1 = parent.getItemAtPosition(position).toString();
                Toast.makeText(getApplicationContext(),"Selected "+items1, Toast.LENGTH_SHORT).show();
            }
        });

        autoCompleteTxt2 = findViewById(R.id.Time);
        adapterItems2 = new ArrayAdapter<String>(this, R.layout.list_item,items2);
        autoCompleteTxt2.setAdapter(adapterItems2);
        autoCompleteTxt2.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String items2 = parent.getItemAtPosition(position).toString();
                Toast.makeText(getApplicationContext(),"Selected "+items2, Toast.LENGTH_SHORT).show();
            }
        });

        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()){
                    maxId = (int)snapshot.getChildrenCount();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


        bookSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!validateName() | !validateEmail() | !validateCity() | !validatePhoneNo() | !validatePincode() | !validateState() | !validateHouse() | !validateArea() | !validateService() | !validateService() | !validateIssueDesc() | !validateDate() | !validateTime()){
                    return;
                }
                String Name = Objects.requireNonNull(bookName.getEditText()).getText().toString();
                String PhoneNo = Objects.requireNonNull(bookPhoneNo.getEditText()).getText().toString();
                String Email = Objects.requireNonNull(bookEmail.getEditText()).getText().toString();
                String PinCode = Objects.requireNonNull(bookPinCode.getEditText()).getText().toString();
                String State = Objects.requireNonNull(bookState.getEditText()).getText().toString();
                String City = Objects.requireNonNull(bookCity.getEditText()).getText().toString();
                String HouseNo = Objects.requireNonNull(bookHouseNo.getEditText()).getText().toString();
                String Area = Objects.requireNonNull(bookArea.getEditText()).getText().toString();
                String Service = Objects.requireNonNull(bookService.getEditText()).getText().toString();
                String IssueDesc = bookIssueDesc.getEditText().getText().toString();
                String Date = inputDate1.getText().toString();
                String Time = bookTime.getEditText().getText().toString();

                BookingHelperClass bookingHelperClass = new BookingHelperClass(Name, PhoneNo, Email, PinCode, State, City, HouseNo, Area, Service, IssueDesc, Date, Time);
//                BookingHelperClass bookingHelperClass = new BookingHelperClass(Name);
                reference.child(String.valueOf(maxId+1)).setValue(bookingHelperClass);
                Intent intent = new Intent(BookingForm.this, BookingHistory.class);
                startActivity(intent);
            }
        });
    }
    private boolean validateName(){
        String val = Objects.requireNonNull(bookName.getEditText()).getText().toString();

        if(val.isEmpty()){
            bookName.setError("Field Can't be Empty!");
            return false;
        }
        else{
            bookName.setError(null);
            bookName.setErrorEnabled(false);
            return true;
        }
    }

    private boolean validateCity(){
        String val = Objects.requireNonNull(bookCity.getEditText()).getText().toString();
        String noWhiteSpace = "\\A\\w{4,20}\\z";

        if(val.isEmpty()){
            bookCity.setError("Field Can't be Empty!");
            return false;
        }
        else{
            bookCity.setError(null);
            bookCity.setErrorEnabled(false);

            return true;
        }
    }

    private boolean validateEmail(){
        String val = Objects.requireNonNull(bookPhoneNo.getEditText()).getText().toString();
        String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";

        if (val.isEmpty()) {
            bookPhoneNo.setError("Field cannot be empty");
            return false;
        } else if (!val.matches(emailPattern)) {
            bookPhoneNo.setError("Invalid email address");
            return false;
        } else {
            bookPhoneNo.setError(null);
            bookPhoneNo.setErrorEnabled(false);
            return true;
        }
    }

    private boolean validatePhoneNo(){
        String val = Objects.requireNonNull(bookEmail.getEditText()).getText().toString();

        if (val.isEmpty()) {
            bookEmail.setError("Field cannot be empty");
            return false;
        } else {
            bookEmail.setError(null);
            bookEmail.setErrorEnabled(false);
            return true;
        }
    }

    private boolean validatePincode(){
        String val = Objects.requireNonNull(bookPinCode.getEditText()).getText().toString();

        if (val.isEmpty()) {
            bookPinCode.setError("Field cannot be empty");
            return false;
        } else {
            bookPinCode.setError(null);
            bookPinCode.setErrorEnabled(false);
            return true;
        }
    }

    private boolean validateState(){
        String val = Objects.requireNonNull(bookState.getEditText()).getText().toString();

        if (val.isEmpty()) {
            bookState.setError("Field cannot be empty");
            return false;
        } else {
            bookState.setError(null);
            bookState.setErrorEnabled(false);
            return true;
        }
    }

    private boolean validateHouse(){
        String val = Objects.requireNonNull(bookHouseNo.getEditText()).getText().toString();

        if (val.isEmpty()) {
            bookHouseNo.setError("Field cannot be empty");
            return false;
        } else {
            bookHouseNo.setError(null);
            bookHouseNo.setErrorEnabled(false);
            return true;
        }
    }

    private boolean validateArea(){
        String val = Objects.requireNonNull(bookArea.getEditText()).getText().toString();

        if (val.isEmpty()) {
            bookArea.setError("Field cannot be empty");
            return false;
        } else {
            bookArea.setError(null);
            bookArea.setErrorEnabled(false);
            return true;
        }
    }

    private boolean validateService(){
        String val = Objects.requireNonNull(bookService.getEditText()).getText().toString();

        if (val.isEmpty()) {
            bookService.setError("Field cannot be empty");
            return false;
        } else {
            bookService.setError(null);
            bookService.setErrorEnabled(false);
            return true;
        }
    }

    private boolean validateIssueDesc(){
        String val = Objects.requireNonNull(bookIssueDesc.getEditText()).getText().toString();

        if (val.isEmpty()) {
            bookIssueDesc.setError("Field cannot be empty");
            return false;
        } else {
            bookIssueDesc.setError(null);
            bookIssueDesc.setErrorEnabled(false);
            return true;
        }
    }

    private boolean validateDate(){
        String val = Objects.requireNonNull(bookDate.getEditText()).getText().toString();

        if (val.isEmpty()) {
            bookIssueDesc.setError("Field cannot be empty");
            return false;
        } else {
            bookDate.setError(null);
            bookDate.setErrorEnabled(false);
            return true;
        }
    }

    private boolean validateTime(){
        String val = Objects.requireNonNull(bookTime.getEditText()).getText().toString();

        if (val.isEmpty()) {
            bookTime.setError("Field cannot be empty");
            return false;
        } else {
            bookTime.setError(null);
            bookTime.setErrorEnabled(false);
            return true;
        }
    }

}