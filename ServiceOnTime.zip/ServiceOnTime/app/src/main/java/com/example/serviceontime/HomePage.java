package com.example.serviceontime;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.icu.number.Scale;
import android.os.Bundle;
import android.transition.Slide;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ViewFlipper;

import com.denzcoskun.imageslider.ImageSlider;
import com.denzcoskun.imageslider.constants.ScaleTypes;
import com.denzcoskun.imageslider.models.SlideModel;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class HomePage extends AppCompatActivity {

    ViewFlipper flipper;
    RecyclerView rcv, rcv1, rcv2, rcv3;
    myadapter adapter;
    myadapterGrid adapterGrid;
    FloatingActionButton bookButton;
    ImageSlider imageSlider;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);
        Objects.requireNonNull(getSupportActionBar()).hide();

        imageSlider = findViewById(R.id.slider);
        List<SlideModel> slideModels = new ArrayList<>();
        slideModels.add(new SlideModel(R.drawable.electrical, ScaleTypes.FIT));
        slideModels.add(new SlideModel(R.drawable.plumber, ScaleTypes.FIT));
        slideModels.add(new SlideModel(R.drawable.carpenter, ScaleTypes.FIT));

        imageSlider.setImageList(slideModels, ScaleTypes.FIT);


        bookButton = findViewById(R.id.bookButtion);
        bookButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(HomePage.this,BookingForm.class);
                startActivity(intent);
            }
        });

        BottomNavigationView bottomNavigationView;
        bottomNavigationView = findViewById(R.id.bottomNavigation);

        bottomNavigationView.setSelectedItemId(R.id.menu_home);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()){
                    case R.id.menu_profile:
                        startActivity(new Intent(getApplicationContext(),
                                UserProfile.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.menu_home:
                        return true;
                    case R.id.menu_professional:
                        startActivity(new Intent(getApplicationContext(),
                                ProfessionalsView.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.menu_history:
                        startActivity(new Intent(getApplicationContext(),
                                BookingHistory.class));
                        overridePendingTransition(0,0);
                        return true;

                }
                return false;
            }
        });

//        int imgArray[] = {R.drawable.electrical,R.drawable.carpenter,R.drawable.plumber};
//        flipper = findViewById(R.id.flipper);
//
//        for(int i = 0; i<imgArray.length; i++){
//            showImage(imgArray[i]);
//        }

        rcv = findViewById(R.id.rclView);
        rcv1 = findViewById(R.id.rclView2);
        rcv2 = findViewById(R.id.rclView3);
        rcv3 = findViewById(R.id.rclView4);
//        rcv.setLayoutManager(new LinearLayoutManager(this));  //This is in VerticalCardView

//        LinearLayoutManager layoutManager = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL,false);
//        rcv.setLayoutManager(layoutManager); //This is horizontal Card View

        GridLayoutManager gridLayoutManager = new GridLayoutManager(this, 2);
        rcv.setLayoutManager(gridLayoutManager);

        adapter = new myadapter(dataqueue());
        rcv.setAdapter(adapter);

        GridLayoutManager gridLayoutManager1 = new GridLayoutManager(this,3);
        rcv1.setLayoutManager(gridLayoutManager1);

        adapterGrid = new myadapterGrid(dataqueue1());
        rcv1.setAdapter(adapterGrid);

        GridLayoutManager gridLayoutManager2 = new GridLayoutManager(this,3);
        rcv2.setLayoutManager(gridLayoutManager2);

        adapterGrid = new myadapterGrid(dataqueue2());
        rcv2.setAdapter(adapterGrid);

        GridLayoutManager gridLayoutManager3 = new GridLayoutManager(this,3);
        rcv3.setLayoutManager(gridLayoutManager3);

        adapterGrid = new myadapterGrid(dataqueue3());
        rcv3.setAdapter(adapterGrid);

    }

    public ArrayList<Model> dataqueue(){
        ArrayList<Model> holder = new ArrayList<>();
        Model ob1 = new Model();
        ob1.setDesc("Experienced");
//        ob1.setDesc("Desktop Programming");
        ob1.setImgname(R.drawable.experinced);
        holder.add(ob1);

        Model ob2 = new Model();
        ob2.setDesc("Skilled and Capable");
//        ob2.setDesc("Desktop Programming");
        ob2.setImgname(R.drawable.skilled);
        holder.add(ob2);

        Model ob3 = new Model();
        ob3.setDesc("Reliable");
//        ob3.setDesc("Desktop Programming");
        ob3.setImgname(R.drawable.reliability);
        holder.add(ob3);

        Model ob4 = new Model();
        ob4.setDesc("Flexible");
//        ob4.setDesc("Desktop Programming");
        ob4.setImgname(R.drawable.flexible);
        holder.add(ob4);

        return holder;
    }

    public ArrayList<ModelGrid> dataqueue1(){
        ArrayList<ModelGrid> holder1 = new ArrayList<>();
        ModelGrid obj1 = new ModelGrid();
        obj1.setGrid_desc("Light Upgrades");
        obj1.setGrid_imgname(R.drawable.lightbulb);
        holder1.add(obj1);

        ModelGrid obj2 = new ModelGrid();
        obj2.setGrid_desc("Ceiling Fan Upgrades");
        obj2.setGrid_imgname(R.drawable.ceilingfan);
        holder1.add(obj2);

        ModelGrid obj3 = new ModelGrid();
        obj3.setGrid_desc("BackUp Generator");
        obj3.setGrid_imgname(R.drawable.electricgenerator);
        holder1.add(obj3);

        ModelGrid obj4 = new ModelGrid();
        obj4.setGrid_desc("Wire Upgrades");
        obj4.setGrid_imgname(R.drawable.wiring);
        holder1.add(obj4);

        ModelGrid obj5 = new ModelGrid();
        obj5.setGrid_desc("Electrical Panel Replacement");
        obj5.setGrid_imgname(R.drawable.electricalpanel);
        holder1.add(obj5);

        ModelGrid obj6 = new ModelGrid();
        obj6.setGrid_desc("Other Electrical Service");
        obj6.setGrid_imgname(R.drawable.engineer);
        holder1.add(obj6);

        return  holder1;
    }

    public ArrayList<ModelGrid> dataqueue2(){
        ArrayList<ModelGrid> holder1 = new ArrayList<>();
        ModelGrid obj1 = new ModelGrid();
        obj1.setGrid_desc("Tap, WashBasin & Sink");
        obj1.setGrid_imgname(R.drawable.washbasin);
        holder1.add(obj1);

        ModelGrid obj2 = new ModelGrid();
        obj2.setGrid_desc("Blocks & Leakages");
        obj2.setGrid_imgname(R.drawable.leaking);
        holder1.add(obj2);

        ModelGrid obj3 = new ModelGrid();
        obj3.setGrid_desc("Toiler & Sanitary Work");
        obj3.setGrid_imgname(R.drawable.publictoilet);
        holder1.add(obj3);

        ModelGrid obj4 = new ModelGrid();
        obj4.setGrid_desc("Pipe Fitting");
        obj4.setGrid_imgname(R.drawable.tubes);
        holder1.add(obj4);

        ModelGrid obj5 = new ModelGrid();
        obj5.setGrid_desc("Geyser Installation");
        obj5.setGrid_imgname(R.drawable.geyser);
        holder1.add(obj5);

        ModelGrid obj6 = new ModelGrid();
        obj6.setGrid_desc("Other Plumbing Service");
        obj6.setGrid_imgname(R.drawable.plumberr);
        holder1.add(obj6);

        return  holder1;
    }

    public ArrayList<ModelGrid> dataqueue3(){
        ArrayList<ModelGrid> holder1 = new ArrayList<>();
        ModelGrid obj1 = new ModelGrid();
        obj1.setGrid_desc("General Carpentry Work");
        obj1.setGrid_imgname(R.drawable.toolbox);
        holder1.add(obj1);

        ModelGrid obj2 = new ModelGrid();
        obj2.setGrid_desc("Furniture Installation & Assembly");
        obj2.setGrid_imgname(R.drawable.furnitures);
        holder1.add(obj2);

        ModelGrid obj3 = new ModelGrid();
        obj3.setGrid_desc("New Furniture");
        obj3.setGrid_imgname(R.drawable.hammer);
        holder1.add(obj3);

        ModelGrid obj4 = new ModelGrid();
        obj4.setGrid_desc("Bolt, Latch & Handle Work ");
        obj4.setGrid_imgname(R.drawable.doors);
        holder1.add(obj4);

        ModelGrid obj5 = new ModelGrid();
        obj5.setGrid_desc("Modular Kitchen Designing");
        obj5.setGrid_imgname(R.drawable.kitchen);
        holder1.add(obj5);

        ModelGrid obj6 = new ModelGrid();
        obj6.setGrid_desc("Other Carpenter Service");
        obj6.setGrid_imgname(R.drawable.carpenterr);
        holder1.add(obj6);

        return  holder1;
    }



//    public void showImage(int img){
//        ImageView imageview = new ImageView(this);
//        imageview.setBackgroundResource(img);
//
//        flipper.addView(imageview);
//        flipper.setFlipInterval(3000);
//        flipper.setAutoStart(true);
//        flipper.setInAnimation(this, android.R.anim.slide_in_left);
//        flipper.setOutAnimation(this, android.R.anim.slide_out_right);
//    }
}