package com.example.serviceontime;

public class ModelGrid {
    private String grid_desc;
    private int grid_imgname;

    public String getGrid_desc() {
        return grid_desc;
    }

    public void setGrid_desc(String grid_desc) {
        this.grid_desc = grid_desc;
    }

    public int getGrid_imgname() {
        return grid_imgname;
    }

    public void setGrid_imgname(int grid_imgname) {
        this.grid_imgname = grid_imgname;
    }
}
