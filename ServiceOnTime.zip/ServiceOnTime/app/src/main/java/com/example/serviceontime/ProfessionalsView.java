package com.example.serviceontime;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.Objects;

public class ProfessionalsView extends AppCompatActivity {

    RecyclerView recyclerView;
    proAdapter adapterPro;
    FloatingActionButton bookButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_professionals_view);
        Objects.requireNonNull(getSupportActionBar()).hide();

        recyclerView = findViewById(R.id.proRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        adapterPro = new proAdapter(infoQueue());
        recyclerView.setAdapter(adapterPro);

        bookButton = findViewById(R.id.bookButtion);
        bookButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ProfessionalsView.this,BookingForm.class);
                startActivity(intent);
            }
        });

        BottomNavigationView bottomNavigationView;
        bottomNavigationView = findViewById(R.id.bottomNavigation);

        bottomNavigationView.setSelectedItemId(R.id.menu_professional);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()){
                    case R.id.menu_profile:
                        startActivity(new Intent(getApplicationContext(),
                                UserProfile.class));

                        overridePendingTransition(0,0);

                        return true;
                    case R.id.menu_professional:
                        return true;
                    case R.id.menu_home:
                        startActivity(new Intent(getApplicationContext(),
                                HomePage.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.menu_history:
                        startActivity(new Intent(getApplicationContext(),
                                BookingHistory.class));
                        overridePendingTransition(0,0);
                        return true;

                }
                return false;
            }
        });

    }
    public ArrayList<proModel> infoQueue(){
        ArrayList<proModel> holder = new ArrayList<>();
        proModel obj1 = new proModel();
        obj1.setEmpName("Amit Kumar");
        obj1.setEmpDesc("Electrical Engineer\n\nHi! Having worked in countless spaces I know each project, large or small, is unique and important to my clients. Design, installation, mounting, electrical, plumbing, painting, assembly, and more. I work with care and detail to get it done right the first time and off the \"to-do list\". I look forward to working with you. Please send me a quick message after booking to get started. Thankyou!");
        obj1.setEmpImg(R.drawable.amit);
        obj1.setEmpRating(R.drawable.rating);
        holder.add(obj1);

        proModel obj2 = new proModel();
        obj2.setEmpName("Harpal Sandhu");
        obj2.setEmpDesc("Carpenter\n\nI'm Harpal Sandhu I know each project, large or small, is unique and important to my clients. Design, installation, mounting, electrical, plumbing, painting, assembly, and more. I work with care and detail to get it done right the first time and off the \"to-do list\". I look forward to working with you. Please send me a quick message after booking to get started. Thankyou!");
        obj2.setEmpImg(R.drawable.pugg);
        obj2.setEmpRating(R.drawable.ratingg);
        holder.add(obj2);

        proModel obj3 = new proModel();
        obj3.setEmpName("Gagan");
        obj3.setEmpDesc("Electrical Engineer\n\nHi, my names Gagan. I do household repairs and services in the Richfield area. I do drywall repairs, faucets, light fixtures, assemblies, installations, haul aways, and just about anything around the house. Feel free to reach out and we can talk about what I do and how I can help you?");
        obj3.setEmpImg(R.drawable.gagan);
        obj3.setEmpRating(R.drawable.rating);
        holder.add(obj3);

        proModel obj4 = new proModel();
        obj4.setEmpName("Chris Evans");
        obj4.setEmpDesc("Plumber\n\nHello, My name is Chris Evans, I have been a carpenter for 6+ years and l I'm a military veteran. I am here to meet and/or exceed your expectations. I look forward to working with you. I do drywall repairs, faucets, light fixtures, assemblies, installations, haul aways, and just about anything around the house. Feel free to reach out and we can talk about what I do and how I can help you.?");
        obj4.setEmpImg(R.drawable.aka);
        obj4.setEmpRating(R.drawable.ratingg);
        holder.add(obj4);

        return holder;
    }
}