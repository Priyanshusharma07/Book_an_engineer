package com.example.serviceontime;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Objects;

public class SignUp extends AppCompatActivity {

    TextInputLayout regName, regUsername, regEmail, regPassword, regPhoneNo;
    Button regSignUp, regLogin;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        Objects.requireNonNull(getSupportActionBar()).hide();
        setContentView(R.layout.activity_sign_up);

        regName = findViewById(R.id.regName);
        regUsername = findViewById(R.id.regUsername);
        regEmail = findViewById(R.id.regEmail);
        regPassword = findViewById(R.id.regPassword);
        regPhoneNo = findViewById(R.id.regPhoneNo);
        regSignUp = findViewById(R.id.regSignUp);
        regLogin = findViewById(R.id.regLogin);
//
    }



    public void registerUser(View view){
        FirebaseDatabase rootNode = FirebaseDatabase.getInstance("https://serviceontimeapp-d7c17-default-rtdb.firebaseio.com/");
        DatabaseReference reference = rootNode.getReference("Users");

        if(!validateName() | !validateEmail() | !validatePassword() | !validatePhoneNo() | !validateUsername()){
            return;
        }

        String name = Objects.requireNonNull(regName.getEditText()).getText().toString();
        String username = Objects.requireNonNull(regUsername.getEditText()).getText().toString();
        String email = Objects.requireNonNull(regEmail.getEditText()).getText().toString();
        String phoneNo = Objects.requireNonNull(regPhoneNo.getEditText()).getText().toString();
        String password = Objects.requireNonNull(regPassword.getEditText()).getText().toString();

//        Intent intent = new Intent(getApplicationContext(), Login.class);
////        intent.putExtra("phoneNo", phoneNo);
//        intent.putExtra("name", name);
//        intent.putExtra("username", username);
//        intent.putExtra("email", email);
//        intent.putExtra("phoneNo", phoneNo);
//        intent.putExtra("password", password);
//        startActivity(intent);

        UserHelperClass helperClass = new UserHelperClass(name, username, email, phoneNo, password);
        reference.child(username).setValue(helperClass);

        Toast.makeText(SignUp.this, "Account Created", Toast.LENGTH_SHORT).show();
//                FirebaseDatabase database = FirebaseDatabase.getInstance("https://serviceontimeapp-d7c17-default-rtdb.firebaseio.com/");
//                DatabaseReference myRef = database.getReference("Users");
//
//                myRef.setValue("Hello, World!");
    }

    public void openActivity(View view){
        Intent intent = new Intent(this, Login.class);
        startActivity(intent);
    }

    private boolean validateName(){
        String val = Objects.requireNonNull(regName.getEditText()).getText().toString();

        if(val.isEmpty()){
            regName.setError("Field Can't be Empty!");
            return false;
        }
        else{
            regName.setError(null);
            regName.setErrorEnabled(false);
            return true;
        }
    }

    private boolean validateUsername(){
        String val = Objects.requireNonNull(regUsername.getEditText()).getText().toString();
        String noWhiteSpace = "\\A\\w{4,20}\\z";

        if(val.isEmpty()){
            regUsername.setError("Field Can't be Empty!");
            return false;
        }
        else if(val.length()>=15) {
            regUsername.setError("Username too long!");
            return false;
        }
        else if(!val.matches(noWhiteSpace)) {
            regUsername.setError("White Spaces are not allowed");
            return false;
        }
        else{
            regUsername.setError(null);
            regUsername.setErrorEnabled(false);

            return true;
        }
    }

    private boolean validateEmail(){
        String val = Objects.requireNonNull(regEmail.getEditText()).getText().toString();
        String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";

        if (val.isEmpty()) {
            regEmail.setError("Field cannot be empty");
            return false;
        } else if (!val.matches(emailPattern)) {
            regEmail.setError("Invalid email address");
            return false;
        } else {
            regEmail.setError(null);
            regEmail.setErrorEnabled(false);
            return true;
        }
    }

    private boolean validatePhoneNo(){
        String val = Objects.requireNonNull(regPhoneNo.getEditText()).getText().toString();

        if (val.isEmpty()) {
            regPhoneNo.setError("Field cannot be empty");
            return false;
        } else {
            regPhoneNo.setError(null);
            regPhoneNo.setErrorEnabled(false);
            return true;
        }
    }

    private boolean validatePassword(){
        String val = Objects.requireNonNull(regPassword.getEditText()).getText().toString();
        String passwordVal = "^" +
                //"(?=.*[0-9])" +         //at least 1 digit
                //"(?=.*[a-z])" +         //at least 1 lower case letter
                "(?=.*[A-Z])" +         //at least 1 upper case letter
                "(?=.*[a-zA-Z])" +      //any letter
                "(?=.*[@#$%^&+=])" +    //at least 1 special character
                "(?=\\S+$)" +           //no white spaces
                ".{4,}" +               //at least 4 characters
                "$";

        if (val.isEmpty()) {
            regPassword.setError("Field cannot be empty");
            return false;
        } else if (!val.matches(passwordVal)) {
            regPassword.setError("Password is too weak");
            return false;
        } else {
            regPassword.setError(null);
            regPassword.setErrorEnabled(false);
            return true;
        }
    }

}