package com.example.serviceontime;

public class BookingModel {
    String Date, Name, PhoneNo, Time, Service, IssueDesc;

    public BookingModel(String date, String name, String phoneNo, String time, String service, String issueDesc) {
        Date = date;
        Name = name;
        PhoneNo = phoneNo;
        Time = time;
        Service = service;
        IssueDesc = issueDesc;
    }

    BookingModel(){

    }

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getPhoneNo() {
        return PhoneNo;
    }

    public void setPhoneNo(String phoneNo) {
        PhoneNo = phoneNo;
    }

    public String getTime() {
        return Time;
    }

    public void setTime(String time) {
        Time = time;
    }

    public String getService() {
        return Service;
    }

    public void setService(String service) {
        Service = service;
    }

    public String getIssueDesc() {
        return IssueDesc;
    }

    public void setIssueDesc(String issueDesc) {
        IssueDesc = issueDesc;
    }



}
